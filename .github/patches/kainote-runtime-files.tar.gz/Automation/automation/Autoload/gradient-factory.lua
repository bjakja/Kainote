﻿--[[
Copyright (c) 2009 Muhammad Lukman Nasaruddin (ai-chan)
Copyright (c) 2021 Marcin Drob (Bakura)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 Automation script: Gradient Factory

]]

script_name = "Gradient Factory v2.6"
script_description = "Color gradient generator by ai-chan and Bakura"
script_author = "Muhammad Lukman Nasaruddin (ai-chan) and Bakura"
script_version = "2.6"
script_modified = "11 09 2021"

include("karaskel.lua")

if not gradient then gradient = {} end

gradient.conf = {
    [1] = { class = "label"; x = 0; y = 0; height = 1; width = 5; label = string.format("%s by ai-chan (updated %s)", script_name, script_modified) }
    ,
    [3] = { label = "Apply to"; class = "label"; x = 0; y = 1; height = 1; width = 1 }
    ,
    [4] = { name = "applyto"; class = "dropdown"; x = 1; y = 1; height = 1; width = 4; items = { }; value = nil }
    ,
    [5] = { label = "Mode"; class = "label"; x = 0; y = 2; height = 1; width = 1 }
    ,
    [6] = { name = "mode"; class = "dropdown"; x = 1; y = 2; height = 1; width = 4;
        items = { "Smooth", "Smooth (Vertical)", "By character", "By syllable" }; value = "Smooth (Vertical)"
    }
    ,
    [8] = { label = "Pixel per strip (for Smooth modes)"; class = "label"; x = 0; y = 3; height = 1; width = 3 }
    ,
    [9] = { name = "stripx"; class = "intedit"; x = 3; y = 3; height = 1; width = 2; min = 1; max = 100; value = 4 }
	,
	[10] = { class = "label"; x = 0; y = 4; height = 1; width = 3; label = "Truncate from top"}
    ,
    [11] = { name = "striptop"; class = "intedit"; x = 3; y = 4; height = 1; width = 2; min = -500; max = 1000; value = 5; hint = "It respects also negative values\nwhen normally text is truncated"}
	,
	[12] = { class = "label"; x = 0; y = 5; height = 1; width = 3; label = "Truncate from bottom"}
	,
	[13] = { name = "stripbottom"; class = "intedit"; x = 3; y = 5; height = 1; width = 2; min = -500; max = 1000; value = 5; hint = "It respects also negative values\nwhen normally text is truncated"}
	,
	[14] = { class = "label"; x = 0; y = 6; height = 1; width = 3; label = "Truncate from left"}
	,
	[15] = { name = "stripleft"; class = "intedit"; x = 3; y = 6; height = 1; width = 2; min = -500; max = 1000; value = 0; hint = "It respects also negative values\nwhen normally text is truncated"}
	,
	[16] = { class = "label"; x = 0; y = 7; height = 1; width = 3; label = "Truncate from right"}
	,
	[17] = { name = "stripright"; class = "intedit"; x = 3; y = 7; height = 1; width = 2; min = -500; max = 1000; value = 0; hint = "It respects also negative values\nwhen normally text is truncated"}
    ,
    [18] = { label = "Primary"; class = "label"; x = 1; y = 8; height = 1; width = 1 }
    ,
    [19] = { name = "primary_mode"; class = "dropdown"; x = 1; y = 9; height = 1; width = 1;
        items = { }; value = "Ignore"
    }
    ,
    [20] = { label = "Secondary"; class = "label"; x = 2; y = 8; height = 1; width = 1 }
    ,
    [21] = { name = "secondary_mode"; class = "dropdown"; x = 2; y = 9; height = 1; width = 1;
        items = { }; value = "Ignore"
    }
    ,
    [22] = { label = "Outline"; class = "label"; x = 3; y = 8; height = 1; width = 1 }
    ,
    [23] = { name = "outline_mode"; class = "dropdown"; x = 3; y = 9; height = 1; width = 1;
        items = { }; value = "Ignore"
    }
    ,
    [24] = { label = "Shadow"; class = "label"; x = 4; y = 8; height = 1; width = 1 }
    ,
    [25] = { name = "shadow_mode"; class = "dropdown"; x = 4; y = 9; height = 1; width = 1;
        items = { }; value = "Ignore"
    }
    ,
    [26] = { label = "Colors"; class = "label"; x = 0; y = 9; height = 1; width = 1 }
    ,
    [27] = { label = "Color 1"; class = "label"; x = 0; y = 10; height = 1; width = 1 }
    ,
    [28] = { name = "primary_color1"; class = "coloralpha"; x =1; y = 10; height = 1; width = 1 }
    ,
    [29] = { name = "secondary_color1"; class = "coloralpha"; x = 2; y = 10; height = 1; width = 1 }
    ,
    [30] = { name = "outline_color1"; class = "coloralpha"; x = 3; y = 10; height = 1; width = 1 }
    ,
    [31] = { name = "shadow_color1"; class = "coloralpha"; x = 4; y = 10; height = 1; width = 1 }
    ,
    [32] = { label = "Color 2"; class = "label"; x = 0; y = 11; height = 1; width = 1 }
    ,
    [33] = { name = "primary_color2"; class = "coloralpha"; x = 1; y = 11; height = 1; width = 1 }
    ,
    [34] = { name = "secondary_color2"; class = "coloralpha"; x = 2; y = 11; height = 1; width = 1 }
    ,
    [35] = { name = "outline_color2"; class = "coloralpha"; x = 3; y = 11; height = 1; width = 1 }
    ,
    [36] = { name = "shadow_color2"; class = "coloralpha"; x = 4; y = 11; height = 1; width = 1 }
    ,
    [37] = { label = "Color 3"; class = "label"; x = 0; y = 12; height = 1; width = 1 }
    ,
    [38] = { name = "primary_color3"; class = "coloralpha"; x = 1; y = 12; height = 1; width = 1 }
    ,
    [39] = { name = "secondary_color3"; class = "coloralpha"; x = 2; y = 12; height = 1; width = 1 }
    ,
    [40] = { name = "outline_color3"; class = "coloralpha"; x = 3; y = 12; height = 1; width = 1 }
    ,
    [41] = { name = "shadow_color3"; class = "coloralpha"; x = 4; y = 12; height = 1; width = 1 }
}

gradient.config_keys = { 4, 6, 9, 11, 13, 15, 17, 19, 21, 23, 25 }

gradient.color_comp_count = 3

gradient.colorkeys = { [1] = "primary"; [2] = "secondary"; [3] = "outline"; [4] = "shadow" }


function gradient.save_config(config)
    for _, i in ipairs(gradient.config_keys) do
        gradient.conf[i].value = config[gradient.conf[i].name]
    end
    for j = 1, gradient.color_comp_count do
        local jk = 23 + 5*j
        for k = jk, jk + 3 do
             gradient.conf[k].value = config[gradient.conf[k].name]
        end
    end
end

function gradient.serialize_config(config)
    local scfg = "Version" .. script_version .. " "
    for _, i in ipairs(gradient.config_keys) do
        scfg = scfg .. config[gradient.conf[i].name] .. string.char(2)
    end
    for j = 1, gradient.color_comp_count do
        local jk = 23 + 5*j
        for k = jk, jk + 3 do
             scfg = scfg .. config[gradient.conf[k].name] .. string.char(2)
        end
    end
    return string.trim(scfg)
end

function gradient.unserialize_config(scfg)
    local c = 0
    local GFVer, scfg = string.headtail(string.trim(scfg))
    local keys_count = #gradient.config_keys
    if GFVer == "Version" .. script_version then
        for g in string.gmatch(scfg, "[^"..string.char(2).."]+") do
            c = c + 1
			
            if c <= keys_count then
                   gradient.conf[gradient.config_keys[c]].value = g
             else
                 local kc = 27 + c - keys_count
                 if kc % 5 == 2 then c, kc = c + 1, kc + 1 end
                 if not gradient.conf[kc] then 
					gradient.append_color_components() 
				 end
                    gradient.conf[kc].value = g
             end
        end
    end
end

function gradient.append_color_components()
    gradient.color_comp_count = gradient.color_comp_count + 1
    gradient.conf[22 + gradient.color_comp_count * 5] = { label = "Color " .. gradient.color_comp_count; class = "label"; x = 0; y = gradient.color_comp_count + 9; height = 1; width = 1 }
	for i = 1, 4 do
        gradient.conf[i + 22 + gradient.color_comp_count * 5] = {
            name = gradient.colorkeys[i] .. "_color" .. gradient.color_comp_count;
            class = "coloralpha"; x = i; y = gradient.color_comp_count + 9; height = 1; width = 1 }
    end
end

function gradient.unappend_color_components()
    for i = 0, 4 do
        gradient.conf[i + 22 + gradient.color_comp_count * 5] = nil
    end
    gradient.color_comp_count = gradient.color_comp_count - 1
end

out = {}

function gradient.process(meta, styles, config, subs, selected, active_line)
	gradient.save_config(config)
    local scfg = gradient.serialize_config(config)
	gradient.save_config_to_disk(scfg)

    -- Get colors
    local colors_count = { primary = 0; secondary = 0; outline = 0; shadow = 0 }
    local colors = { primary = {}; secondary = {}; outline = {}; shadow = {} }
	local alphas = { primary = {}; secondary = {}; outline = {}; shadow = {} }
	local hasAlpha = false
	
    for k = 1,4 do
        local key = gradient.colorkeys[k]
        if config[key .. "_mode"] ~= "Ignore" then
            count, _ = string.headtail(config[key .. "_mode"])
            colors_count[key] = tonumber(count)
        end
        for j = 1,colors_count[key] do
            local htmlcolor = config[key .. "_color" .. j]
			if unicode.len(htmlcolor) > 7 then
				local a, r, g, b = string.match(htmlcolor, "(%x%x)(%x%x)(%x%x)(%x%x)")
				colors[key][j] = ass_color(tonumber(r,16), tonumber(g,16), tonumber(b,16))
				alphas[key][j] = ass_alpha(tonumber(a,16))
				hasAlpha = true
			else
				local r, g, b = string.match(htmlcolor, "(%x%x)(%x%x)(%x%x)")
				colors[key][j] = ass_color(tonumber(r,16), tonumber(g,16), tonumber(b,16))
				alphas[key][j] = ass_alpha(0)
			end
        end
    end
	if not hasAlpha then
		alphas = nil
	end

    if colors_count["primary"] + colors_count["secondary"]+ colors_count["outline"] + colors_count["shadow"] == 0 then
        aegisub.debug.out(0, "Operation failed because you did not configure gradient count for primary/secondary/outline/shadow colors.")
        return false
    end

    -- Mode
    local mode_digest = { ["Smooth"] = 1; ["Smooth (Vertical)"] = 2; ["By character"] = 3; ["By syllable"] = 4 }
    config.mode = mode_digest[config.mode]
	config.karatagfn = function(syl) return "" end

	applyTo, applytoName = string.headtail(config.applyto)
	local isSelected = false
	

	local checkSelections = applyTo == "Selected"
	local allLines = applyTo == "All"
	local styleLines = applyTo == "Style"
	local actorLines = applyTo == "Actor"
	if styleLines or actorLines then
		applytoName = string.sub(applytoName, 3)
	end
	

	local commentPos = -1
	local i = 1
	local orgI = 1
	local selcounter = 1
	
	while i <= #subs do
		
		aegisub.progress.task(string.format("Making gradient, line (%d / %d)", i, #subs))
		aegisub.progress.set((i - 1) / #subs * 100)
		if aegisub.progress.is_cancelled() then 
			--aegisub.log("break")
			break 
		end
			
		local line = subs[i]
		
		if checkSelections and orgI == selected[selcounter] then
			if selcounter > #selected then
				checkSelections = false
				--aegisub.log("end counting %d", #selected)
			end
			--aegisub.log("sel counter %d next %d, %d, %d\n" .. line.text .. "\n", orgI, #selected, selected[selcounter], selcounter)
			selcounter = selcounter + 1
			isSelected = true
		else
			isSelected = false
		end
		orgI = orgI + 1

		if line.class == "dialogue" and not line.comment and (isSelected or allLines or (styleLines and line.style == applytoName) or (actorLines and line.actor == applytoName)) then
		
			if commentPos < 0 then
				commentPos = i
			end
			
			function result()
				lc = copy_line(line);
				table.insert(out,lc)
				return lc
			end
			line.comment = true
			subs.insert(commentPos, line)
			line.comment = false
			i = i + 1
			commentPos = commentPos + 1
			
			if styles[line.style] then
				line.styleref = styles[line.style]
			else
				line.styleref = styles[1]
			end
			
			local marginr=(line.margin_r > 0) and line.margin_r or line.styleref.margin_r
			local marginl=(line.margin_l > 0) and line.margin_l or line.styleref.margin_l
			local margint=(line.margin_t > 0) and line.margin_t or line.styleref.margin_t
			local an = line.styleref.align
			local x = nil
			local y = nil
			local moveToX = nil
			local moveToY = nil
			local moveTime1 = nil
			local moveTime2 = nil
			local textwidth = 0
			local textheight = 0
			
			
			local linetext = ""
			linetext = line.text:gsub("\\an([0-9])",
			function(annum)
				an = tonumber(annum)
				return ""
			end)
			
			line.text = linetext:gsub("\\pos%(([0-9.-]+) ?, ?([0-9.-]+)%)",
			function(posx, posy)
				x = tonumber(posx)
				y = tonumber(posy)
				return ""
			end)
			
			linetext = line.text:gsub("\\move%(([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+)%)",
			function(posx, posy, posx1, posy1)
				x = tonumber(posx)
				y = tonumber(posy)
				moveToX = tonumber(posx1)
				moveToY = tonumber(posy1)
				return ""
			end)
			line.text = linetext:gsub("\\move%(([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+) ?, ?([0-9.-]+)%)",
			function(posx, posy, posx1, posy1, t1, t2)
				x = tonumber(posx)
				y = tonumber(posy)
				moveToX = tonumber(posx1)
				moveToY = tonumber(posy1)
				moveTime1 = tonumber(t1)
				moveTime2 = tonumber(t2)
				return ""
			end)
			
			line.move_distanceX = moveToX ~= nil and moveToX - x or nil
			line.move_distanceY = moveToy ~= nil and moveToY - y or nil
			
			textWithoutSplit = line.text
			hasDrawing = false
			drawingText = ""
			repeat
				a, b, p, toendbracket, rest = string.find(textWithoutSplit, "\\p([0-9]+)([^}]*)}(.*)")
				if p ~= nil then
					textWithoutSplit = rest
					local pnum = tonumber(p)
					if pnum > 0 then
						drawingText = drawingText .. rest
					else
						a, b, before = string.find(textWithoutSplit, "{(.-)\\p0")
						drawingText = string.sub(drawingText, 1, a)
					end
					hasDrawing = true
				end
			until p == nil
			
			local lineCount = 1
			local maxHeight = -1
			textWithoutSplit = string.gsub(textWithoutSplit, "\\(n|N)", 
				function(s)
					lineCount = lineCount + 1
					return "{\\" .. s .. "}"
				end)
				
			textWithoutSplit = string.gsub(textWithoutSplit, "\\h", " ")
				
			local maxTextWidth = 0
			local linestyle = copy_line(line.styleref)
			local prevstyle = copy_line(linestyle)
			local first = true
			for beforeText, tagsBlock in string.gmatch(textWithoutSplit .. "{@}", "(.-){([^{}]*)}") do 
				local isSplit = tagsBlock == "\\N" or tagsBlock == "\\n"
				if tagsBlock ~= "" and tagsBlock ~= "@" and not isSplit then 
					--linestyle = copy_line(line.styleref)
					for fs in string.gmatch(tagsBlock .. "\\", "\\fs([0-9.]+)") do 
						linestyle.fontsize = fs
					end
					for fscx in string.gmatch(tagsBlock .. "\\", "\\fscx([0-9.]+)") do 
						linestyle.scale_x = fscx
					end
					for fscy in string.gmatch(tagsBlock .. "\\", "\\fscy([0-9.]+)") do 
						linestyle.scale_y = fscy
					end
					for fn in string.gmatch(tagsBlock .. "\\", "\\fn([^\\}]+)") do 
						--aegisub.log("fn ".. fn .."\n")
						linestyle.fontname = fn
					end
					for fsp in string.gmatch(tagsBlock .. "\\", "\\fsp([0-9.-]+)") do 
						linestyle.spacing = fsp
					end
					if first then
						line.styleref = copy_line(linestyle)
					end
					--aegisub.log("text measuring st"..beforeText.." tb " .. tagsBlock .."\n")
				end 
				
				if beforeText ~= "" then
					--aegisub.log("text measuring "..beforeText.." fn " .. prevstyle.fontname .."\n")
					partLineWidth, partLineHeight, td, te = aegisub.text_extents(prevstyle, beforeText)
					textwidth = textwidth + partLineWidth
					if isSplit and maxTextWidth < textwidth then
						maxTextWidth = textwidth
						textwidth = 0
					end
					if maxHeight < partLineHeight then
						maxHeight = partLineHeight
					end
				end
				prevstyle = copy_line(linestyle)
			end
			
			if maxTextWidth > 0 then
				textwidth = maxTextWidth
			end
			if maxHeight > 0 then
				textheight = maxHeight
			end
			
			local drawingMinX = 0
			local drawingMinY = 0
			local drawingMaxX = 0
			local drawingMaxY = 0
			
			if hasDrawing then
				if drawingText == "" then
					hasDrawing = false
					aegisub.log("Line has empty drawing")
				else
					drawingMinX, drawingMinY, drawingMaxX, drawingMaxY = getVectorDrawingsBoundaries(drawingText)
					
					textwidth = textwidth + drawingMaxX - drawingMinX
					textheight = textheight + drawingMaxY - drawingMinY
					
					--aegisub.log("values %s, %s, %s, %s, %s, %s", drawingMinX, drawingMinY, drawingMaxX, drawingMaxY, textwidth, textheight)
					
				end
			end
			
			
			--orgx = 0
			--orgy = 0
			if x == nil then
				if an % 3 == 1 then
					x = marginl
					line.pos_x = x
				elseif an % 3 == 2 then
					x = (meta.res_x - textwidth) / 2
					line.pos_x = meta.res_x / 2
				else
					x = (meta.res_x - textwidth) - marginr
					line.pos_x = meta.res_x - marginr
				end

				if math.floor(an / 3.1) == 0 then
					y = meta.res_y - margint
					line.pos_y = y
				elseif math.floor(an/3.1) == 1 then
					y = (meta.res_y / 2) + (textheight / 2)
					line.pos_y = (meta.res_y / 2)
				elseif math.floor(an/3.1) == 2 then
					y = margint + textheight
					line.pos_y = margint
				end
				
				
			else
				line.pos_x = x
				line.pos_y = y
				if an % 3 == 2 then
					x = x - (textwidth / 2)
				elseif an % 3 == 0 then
					x = x - textwidth
				end
				if math.floor(an / 3.1) == 2 then
					y = y + textheight
				elseif math.floor(an / 3.1) == 1 then
					y = y + (textheight / 2)
				end
			end	
			
			if y ~= nil then
				if math.floor(an / 3.1) == 2 then
					drawingMaxY = drawingMaxY + y
					drawingMinY = drawingMinY + y
				elseif math.floor(an / 3.1) == 1 then
					drawingMaxY = drawingMaxY + (y - (textheight / 2))
					drawingMinY = drawingMinY + (y - (textheight / 2))
				else
					drawingMaxY = drawingMaxY + (y - textheight)
					drawingMinY = drawingMinY + (y - textheight)
				end
			end
					
			line.height = textheight
			line.y = y - (line.height / 2)
			line.i = i
			line.width = textwidth
			line.x = x + (line.width / 2)
			line.left = hasDrawing and drawingMinX + x or x
			line.right = hasDrawing and drawingMaxX + x or  line.left + line.width
			line.top = hasDrawing and drawingMinY or y - line.height
			line.bottom = hasDrawing and drawingMaxY or y
			line.an = an
			line.has_drawing = hasDrawing
			line.text_stripped = line.text:gsub("\\{([^}}]*)}","")
			line.move_toX = moveToX
			line.move_toY = moveToY
			line.move_time1 = moveTime1
			line.move_time2 = moveTime2
			line.kara={}
			line.kara= aegisub.parse_karaoke_data(line)
			--aegisub.log("measures x %s, y %s, xL %s, yL %s, xR %s, yR %s", line.x, line.y, line.xL, line.yL, line.xR, line.yR)
			--out
			subs.delete(i)
			i = i - 1
			
			--aegisub.log("process gradient")
			gradient.do_line(meta, styles, config, colors, alphas, line)
			--aegisub.log(string.format("process gradient out table %d", #out))
			if #out>0 then

				for g = #out, 1, -1 do

					subs.insert(i + 1,out[g])

				end

				i = i + #out
				out = {}
			end
		end
		i = i + 1
	end
end

function getVectorDrawingsBoundaries(text)
	local drawing = text .. " "
	local minX = 10000000
	local minY = 10000000
	local maxX = -10000000
	local maxY = -10000000
	
	for i = 1, 10000000 do
		a, b, before, drawx, drawy, rest = string.find(drawing, "(.-)([0-9.-]+) ([0-9.-]+)(.*)")
		drawing = rest
		if drawx == nil or rest == nil then
			if rest ~= nil and string.match(rest, "[0-9.-]") ~= nil then
				error("Unpaired draw points\n")
				return nil
			end
			break
		end
		if string.match(before, "[0-9.-]") ~= nil then
			error("Bad drawing in: " .. before .. " " .. drawx .. " " .. drawy .. " " .. rest .. "\n")
			return nil
		end
		--aegisub.log("cl" .. drawx .. " " .. drawy .. " before " .. before .. "\n")
		local dx = tonumber(drawx)
		local dy = tonumber(drawy)
		if minX > dx then
			minX = dx
		end
		if minY > dy then
			minY = dy
		end
		if maxX < dx then
			maxX = dx
		end
		if maxY < dy then
			maxY = dy
		end
	end
	return minX, minY, maxX, maxY
end


function gradient.do_line(meta, styles, config, colors, alphas, line)
    local linetext = ""
    local mode = config.mode
    if #line.kara == 0 and mode == 4 then mode = 3 end
    local linewidth = line.width + 2*line.styleref.outline + line.styleref.shadow - config.stripleft - config.stripright
    local lineheight = line.height + 2*line.styleref.outline + line.styleref.shadow - config.striptop - config.stripbottom
    local lineleft = line.left - line.styleref.outline + config.stripleft
    local lineright = line.right + line.styleref.outline + line.styleref.shadow - config.stripright
    local linetop = line.top - line.styleref.outline + config.striptop
    local linebottom = line.bottom + line.styleref.outline + line.styleref.shadow - config.stripbottom
	
	if (mode == 1 and linewidth < config.stripx * 3) or (mode == 2 and lineheight < config.stripx * 3) then
		error("Truncate values are too high")
	end
	

	local animtimes = line.move_time1 ~= nil and string.format("%s,%s,", line.move_time1, line.move_time2) or ""
    -- new in 1.2: preserve \pos and \move
    local pos_mode, pos_tag = line.move_toX ~= nil and 2 or 0, line.move_toX ~= nil and string.format("\\an%d\\move(%s,%s,%s,%s,%s)", line.an, line.pos_x, line.pos_y, line.move_toX, line.move_toY, animtimes) or string.format("\\an%d\\pos(%s,%s)", line.an, line.pos_x, line.pos_y)
	local tagsTable = {"pos", "move", "clip", "iclip"}
	for i = 1, 4 do
		local key = gradient.colorkeys[i]
		local append = 4
        if config[key .. "_mode"] ~= "Ignore" then
			tagsTable[append] = i .. "c"
			append = append + 1
			if alphas then
				tagsTable[append] = i .. "a"
				append = append + 1
			end
			if i == 1 then
				tagsTable[append] = "c"
				append = append + 1
			end
		end
	end
    
    local clipper = function(x1, y1, x2, y2)
         local outstr = string.format("\\clip(%d,%d,%d,%d)", x1, y1, x2, y2)
         if pos_mode > 1 then
            outstr = outstr .. string.format("\\t(%s\\clip(%d,%d,%d,%d))", animtimes, x1 + line.move_distanceX, y1 + line.move_distanceY, x2 + line.move_distanceX, y2 + line.move_distanceY)
        end
        return outstr .. pos_tag
    end

    if mode < 3 then
        --nline = result(line)
        --nline.comment = true
        --nline.effect = string.format("gradient @%x 0", randomtag)
        if #line.kara > 0 then
            for s, syl in ipairs(line.kara) do
                linetext = linetext .. strip_tags(syl.text, tagsTable)
            end
        else
            linetext = strip_tags(line.text, tagsTable)
        end
    end

    if mode == 1 then
        local left, right = 0, config.stripx
        local count = 0
        local nlinewidth = linewidth-config.stripx
        repeat
            nline = result(line)
            nlinetext = string.format("{%s%s}%s",
                      clipper(left == 0 and 0 or left+lineleft,0,right >= linewidth and meta.res_x or right+lineleft,meta.res_y),
                      gradient.color_interpolator(left, nlinewidth, colors, alphas), linetext)
			
            nline.text = string.gsub(nlinetext, "}{", "")
            count = count + 1
            --nline.effect = string.format("gradient @%x %00d", randomtag, count)
            left = right
            right = right + config.stripx
        until left >= linewidth and not aegisub.progress.is_cancelled()
    elseif mode == 2 then
        local top, bottom = 0, config.stripx
        local count = 0
        local nlineheight = lineheight-config.stripx
        repeat
            nline = result(line)
            nlinetext = string.format("{%s%s}%s",
                      clipper(0,top == 0 and 0 or linetop+top,meta.res_x,bottom >= lineheight and meta.res_y or linetop+bottom),
                      gradient.color_interpolator(top, nlineheight, colors, alphas), linetext)
			
            nline.text = string.gsub(nlinetext, "}{", "")
            count = count + 1
            --nline.effect = string.format("gradient @%x %00d", randomtag, count)

            top = bottom
            bottom = bottom + config.stripx
        until top >= lineheight and not aegisub.progress.is_cancelled()
    elseif mode == 3 then
        local left, right, block, blockSplit = 0,0, false, false
		local lastchar = ""
		local linetextts = strip_tags(line.text, tagsTable)
		for char in unicode.chars(linetextts) do
			local split = (lastchar == "\\" and (char == "N" or char == "n" or char == "h"))
			if char == "{" then
				block = true
				linetext = linetext .. char
			elseif char == "}" then
				block = false
				linetext = linetext .. char
			elseif not block and not split and not blockSplit and char ~= " " then
				local width, height, descent, ext_lead = aegisub.text_extents(line.styleref, char)
				right = left + width
				local colortags = gradient.color_interpolator(gradient.calc_j(left, right, line.width), line.width, colors, alphas)
				if colortags ~= "" then colortags = "{" .. colortags .. "}" end
				linetext = linetext .. colortags .. char
				left = right
			else
				if not block then
					local width, height, descent, ext_lead = aegisub.text_extents(line.styleref, char)
					left = left + width
				end
					
				linetext = linetext .. char
			end
			lastchar = char
			blockSplit = split
        end
        if pos_mode > 0 then linetext = string.format("{%s}%s", pos_tag, linetext) end
    elseif mode == 4 then
        for s, syl in ipairs(line.kara) do
            local colortags = gradient.color_interpolator(gradient.calc_j(syl.left, syl.right, line.width), line.width, colors, alphas)
            if colortags ~= "" then colortags = "{" .. colortags .. "}" end
            local syltext = colortags .. strip_tags(syl.text, tagsTable)
            linetext = linetext .. syltext
        end
        if pos_mode > 0 then linetext = string.format("{%s}%s", pos_tag, linetext) end
    end

    if mode > 2 then
        nline = result(line)
        nline.text = string.gsub(linetext, "}{", "")
    end

end

function gradient.calc_j(left, right, width)
    if left + right < width then
        return left + ((right - left) * left / width)
    else
        return left + ((right - left) * right / width)
    end
end

function gradient.color_interpolator(j, maxj, colors, alphas)
    local colors_out = ""
	for c = 1,4 do
        local dcolors = colors[gradient.colorkeys[c]]
        local cc = #dcolors
        if cc > 1 then
            local nmaxj = maxj/(cc-1)
            local k = clamp(math.floor(j/nmaxj), 0, cc-2)
            local nj = j - (k*nmaxj)
            colors_out = colors_out .. string.format("\\%dc%s",c,interpolate_color(nj/nmaxj, dcolors[k+1], dcolors[k+2]))
			if alphas ~= nil then
				local dalphas = alphas[gradient.colorkeys[c]]
				colors_out = colors_out .. string.format("\\%da%s",c,interpolate_alpha(nj/nmaxj, dalphas[k+1], dalphas[k+2]))
			end
        end
    end
    return colors_out
end

function gradient.prepareconfig(styles, subtitles, selected)
    local applyto = 4
    gradient.conf[applyto].items = {}
    oldapplytovalue = gradient.conf[applyto].value
    gradient.conf[applyto].value = "All lines"
    table.insert(gradient.conf[applyto].items, gradient.conf[applyto].value)
    if #selected > 0 then
        applytoselected = string.format("Selected lines (%d)", #selected)
        table.insert(gradient.conf[applyto].items, applytoselected)
		--if has selected lines then apply to selected
        gradient.conf[applyto].value = applytoselected
    end
    for i, style in ipairs(styles) do
        itemname = string.format("Style = %s", style.name)
        table.insert(gradient.conf[applyto].items, itemname)
        if oldapplytovalue == itemname then gradient.conf[applyto].value = itemname end
    end
    local actors = {}
    for i = 1, #subtitles do
        if subtitles[i].class == "dialogue" and not subtitles[i].comment and subtitles[i].actor ~= "" then
            if not actors[subtitles[i].actor] then
                actors[subtitles[i].actor] = true
                itemname = string.format("Actor = %s", subtitles[i].actor)
                table.insert(gradient.conf[applyto].items, itemname)
                   if oldapplytovalue == itemname then gradient.conf[applyto].value = itemname end
            end
        end
    end
    for i = 1, 4 do
        local j = 17 + i * 2
        local found, item = (gradient.conf[j].value == "Ignore"), ""
        gradient.conf[j].items = { [1] = "Ignore" }
        for k = 2, gradient.color_comp_count do
            item = string.format("%d colors", k)
            gradient.conf[j].items[k] = item
            if gradient.conf[j].value == item then found = true end
        end
        if not found then gradient.conf[j].value = item end
    end
end

function gradient.macro_process(subtitles, selected_lines, active_line)
    local meta, styles = karaskel.collect_head(subtitles)

    -- configuration
    --if meta["gradientfactory"] ~= nil then
    --   gradient.unserialize_config(meta["gradientfactory"])
    --end
	gradient.load_config_from_disk()

    -- filter selected_lines
    -- local subs = {}
    -- for _, i in ipairs(selected_lines) do
        -- if not subtitles[i].comment and not gradient.has_gradient(subtitles[i]) then
           -- table.insert(subs,i)
       -- end
    -- end
    -- selected_lines = subs

    -- display dialog
    local cfg_res, config
    repeat
        gradient.prepareconfig(styles, subtitles, selected_lines)
        local dlgbuttons = {"Generate","+colors","-colors","Cancel"}
        if gradient.color_comp_count <= 2 then dlgbuttons = {"Generate","+colors","Cancel"} end
        cfg_res, config = aegisub.dialog.display(gradient.conf, dlgbuttons)
        if cfg_res == "+colors" then
           gradient.save_config(config)
           gradient.append_color_components()
        elseif cfg_res == "-colors" then
           gradient.save_config(config)
           gradient.unappend_color_components()
        end
    until cfg_res ~= "+colors" and cfg_res ~= "-colors"

    if cfg_res == "Generate" then
        result = gradient.process(meta, styles, config, subtitles, selected_lines, active_line)
        if result then
            aegisub.set_undo_point("Generate color gradient")
            aegisub.progress.task("Done")
        else
            aegisub.progress.task("Failed");
        end
    else
        aegisub.progress.task("Cancelled");
    end
end



--check if tag have to be romoved
function check_tag(text, tagTable)
	local ulen = unicode.len(text)
	for i = 1, #tagTable do
		--aegisub.log("tagtable %s", tagTable[i]~=nil and tagTable[i] or "nil")
		if string.match(text, "^" .. tagTable[i] .. "[0-9-.,&A-FH()]*") or (tagTable[i] == "fn" and string.match(text, "^fn(.*)")) then
			return true
		end
	end
	
	return false
end
-- strip unwanted tags
function strip_tags(linetext, tagTable)
	local temptag = ""
	local isBracket = false
	local hasTag = false
	local output_string = ""
	
	for chars in unicode.chars(linetext) do
		if chars == "{" then
			isBracket = true
			output_string = output_string .. chars
			--aegisub.log("1" .. output_string .. "\n")
		elseif chars == "}" then
			isBracket = false
			hasTag = false
			if temptag ~= "" then
				if not check_tag(temptag, tagTable) then
					output_string = output_string .. "\\" .. temptag
					--aegisub.log("2" .. output_string .. "\n")
				end
			end
			temptag = ""
			output_string = output_string .. chars
			--aegisub.log("3" .. output_string .. "\n")
		elseif not isBracket then
			output_string = output_string .. chars
			--aegisub.log("4" .. output_string .. "\n")
		end
		if isBracket and chars == "\\" then
			if temptag ~= "" then
				if not check_tag(temptag, tagTable) then
					output_string = output_string .. "\\" .. temptag
					--aegisub.log("5" .. output_string .. "\n")
				end
			end
			hasTag = true
			temptag = ""
		elseif hasTag then
			temptag = temptag .. chars
		end
			
	end
	return output_string
end

--save config to disk from string
function gradient.save_config_to_disk(confResult)
	path = aegisub.decode_path("?data") .. "\\gradient-factory.conf"
	handle = io.open(path, "w")
	if handle then
		handle:write(confResult)
		handle:close()
	end
end

--load config from disk
function gradient.load_config_from_disk()
	local confResult = ""
	path = aegisub.decode_path("?data") .. "\\gradient-factory.conf"
	handle = io.open(path, "r")
	if handle then
		confResult = handle:read("*all")
		io.close(handle)
		if confResult ~= "" then
			gradient.unserialize_config(confResult)
		end
	end
end

-- register macros
aegisub.register_macro("Generate color gradient", "Generate color gradient", gradient.macro_process)

