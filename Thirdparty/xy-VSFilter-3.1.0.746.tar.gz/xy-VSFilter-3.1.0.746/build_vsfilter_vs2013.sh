#!/bin/sh

sh build_vsfilter.sh -compiler VS2013
