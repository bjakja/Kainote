#include "once_logger.h"

int OnceLogger::s_entered[256] = {0};
