#ifndef __XY_UTILS_03D97DFD_68D1_4760_8F70_8AB38638E015_H__
#define __XY_UTILS_03D97DFD_68D1_4760_8F70_8AB38638E015_H__

#include <atlcoll.h>
#include <atltypes.h>

void MergeRects(const CAtlList<CRect>& input, CAtlList<CRect>* output);


#endif // __XY_UTILS_03D97DFD_68D1_4760_8F70_8AB38638E015_H__
